import React, { useState, useEffect, useMemo } from "react";
import axios from "axios";

const Settings = () => {
  const [activeTab, setActiveTab] = useState("general");
  const [businessDetails, setBusinessDetails] = useState({ name: "", description: "" });
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const selectedBusiness = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("selectedBusiness")) || {};
    } catch {
      console.error("Invalid business data in local storage");
      return {};
    }
  }, []);

  const fetchBusinessDetails = async () => {
    if (!selectedBusiness.id) {
      console.error("No business ID found");
      return;
    }
    try {
      setIsLoading(true);
      const token = localStorage.getItem("token");
      const response = await axios.get(
        `http://localhost:3000/api/businesses/${selectedBusiness.id}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      const { name, description } = response.data.business;
      setBusinessDetails({ name: name || "", description: description || "" });
    } catch (error) {
      console.error("Error fetching business details:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBusinessDetails();
  }, [selectedBusiness.id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setBusinessDetails((prev) => ({ ...prev, [name]: value }));
  };

  const handleSaveChanges = async () => {
    if (!businessDetails.name.trim() || !businessDetails.description.trim()) {
      alert("Name and Description cannot be empty.");
      return;
    }
  
    try {
      setIsSaving(true);
      const token = localStorage.getItem("token");
  
      // Send the request with name and description directly in the body
      await axios.put(
        `http://localhost:3000/api/businesses/${selectedBusiness.id}`,
        {
          name: businessDetails.name,
          description: businessDetails.description,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
  
      alert("Changes saved successfully!");
    } catch (error) {
      console.error("Error saving changes:", error);
      alert("Failed to save changes. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };
  

  const renderTabContent = () => {
    if (activeTab === "general") {
      return (
        <div>
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">
            General Settings
          </h3>
          {isLoading ? (
            <p>Loading...</p>
          ) : (
            <>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">
                  Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={businessDetails.name}
                  onChange={handleInputChange}
                  placeholder="Enter business name"
                  className="mt-1 p-2 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent"
                />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">
                  Description
                </label>
                <textarea
                  name="description"
                  value={businessDetails.description}
                  onChange={handleInputChange}
                  placeholder="Enter a brief description"
                  rows="4"
                  className="mt-1 p-2 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent"
                ></textarea>
              </div>
              <button
                onClick={handleSaveChanges}
                className={`px-4 py-2 rounded-md text-white ${isSaving
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-accent hover:bg-accent-dark"
                  }`}
                disabled={isSaving}
              >
                {isSaving ? "Saving..." : "Save Changes"}
              </button>
            </>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-4">
      <h2 className="text-3xl font-bold text-accent mb-6">Settings</h2>
      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setActiveTab("general")}
          className={`px-4 py-2 rounded-md ${activeTab === "general"
            ? "bg-accent text-white"
            : "bg-gray-200 text-gray-700"
            }`}
        >
          General
        </button>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-md">{renderTabContent()}</div>
    </div>
  );
};

export default Settings;
