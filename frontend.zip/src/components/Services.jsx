import React, { useState } from "react";

const Services = () => {
  const [services, setServices] = useState([
    { id: 1, name: "Haircut", price: "$20", time: "30 mins" },
    { id: 2, name: "Manicure", price: "$25", time: "45 mins" },
    { id: 3, name: "Massage", price: "$50", time: "60 mins" },
  ]);
  const [showAddService, setShowAddService] = useState(false);
  const [newService, setNewService] = useState({ name: "", price: "", time: "" });
  const [editingService, setEditingService] = useState(null);

  const handleAddService = () => {
    if (!newService.name.trim() || !newService.price.trim() || !newService.time.trim()) {
      alert("All fields are required.");
      return;
    }

    const newEntry = { ...newService, id: Date.now() };
    setServices((prev) => [...prev, newEntry]);
    setNewService({ name: "", price: "", time: "" });
    setShowAddService(false);
  };

  const handleEditService = (service) => {
    setEditingService(service);
    setNewService(service);
    setShowAddService(true);
  };

  const handleSaveEdit = () => {
    if (!newService.name.trim() || !newService.price.trim() || !newService.time.trim()) {
      alert("All fields are required.");
      return;
    }

    setServices((prev) =>
      prev.map((service) => (service.id === editingService.id ? newService : service))
    );
    setNewService({ name: "", price: "", time: "" });
    setEditingService(null);
    setShowAddService(false);
  };

  const handleDeleteService = (id) => {
    if (window.confirm("Are you sure you want to delete this service?")) {
      setServices((prev) => prev.filter((service) => service.id !== id));
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-3xl font-bold text-accent mb-6">Services</h2>

      <button
        onClick={() => {
          setShowAddService(true);
          setEditingService(null);
          setNewService({ name: "", price: "", time: "" });
        }}
        className="px-4 py-2 mb-6 bg-accent text-white rounded-md"
      >
        {editingService ? "Edit Service" : "Add New Service"}
      </button>

      {showAddService && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">
            {editingService ? "Edit Service" : "Add New Service"}
          </h3>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Name</label>
            <input
              type="text"
              placeholder="Enter service name"
              value={newService.name}
              onChange={(e) => setNewService({ ...newService, name: e.target.value })}
              className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
            />
          </div>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Price</label>
            <input
              type="text"
              placeholder="Enter price"
              value={newService.price}
              onChange={(e) => setNewService({ ...newService, price: e.target.value })}
              className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
            />
          </div>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Time</label>
            <input
              type="text"
              placeholder="Enter time"
              value={newService.time}
              onChange={(e) => setNewService({ ...newService, time: e.target.value })}
              className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
            />
          </div>
          <button
            onClick={editingService ? handleSaveEdit : handleAddService}
            className="px-4 py-2 bg-green-500 text-white rounded-md"
          >
            {editingService ? "Save Changes" : "Add Service"}
          </button>
          <button
            onClick={() => setShowAddService(false)}
            className="ml-2 px-4 py-2 bg-gray-500 text-white rounded-md"
          >
            Cancel
          </button>
        </div>
      )}

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-2xl font-semibold text-gray-800 mb-4">Service List</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full table-auto">
            <thead>
              <tr>
                <th className="py-2 px-4 text-left">Name</th>
                <th className="py-2 px-4 text-left">Price</th>
                <th className="py-2 px-4 text-left">Time</th>
                <th className="py-2 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {services.map((service) => (
                <tr key={service.id} className="border-t">
                  <td className="py-2 px-4">{service.name}</td>
                  <td className="py-2 px-4">{service.price}</td>
                  <td className="py-2 px-4">{service.time}</td>
                  <td className="py-2 px-4">
                    <button
                      onClick={() => handleEditService(service)}
                      className="px-4 py-2 bg-blue-500 text-white rounded-md"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteService(service.id)}
                      className="ml-2 px-4 py-2 bg-red-500 text-white rounded-md"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Services;