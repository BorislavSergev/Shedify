import React, { useState, useEffect, useMemo } from "react";

const Teams = () => {
  const [showAddMember, setShowAddMember] = useState(false);
  const [showEditMember, setShowEditMember] = useState(false);
  const [currentMember, setCurrentMember] = useState(null);
  const [newMember, setNewMember] = useState({
    firstName: "",
    lastName: "",
    email: "",
    role: "",
    permissions: ["view", "edit", "delete"], // Static permissions for UI
  });
  const [teamMembers, setTeamMembers] = useState([]);

  const permissionsList = ["view", "edit", "delete"];

  // Fetch team members from the backend
  const selectedBusiness = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("selectedBusiness")) || {};
    } catch {
      console.error("Invalid business data in local storage");
      return {};
    }
  }, []);

  const fetchTeamMembers = async () => {
    const token = localStorage.getItem("token");
    try {
      const response = await fetch(
        `http://localhost:3000/api/businesses/${selectedBusiness.id}/team`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (response.ok) {
        const data = await response.json();
        setTeamMembers(data); // Update state with fetched team members
      } else {
        console.error("Failed to fetch team members");
      }
    } catch (error) {
      console.error("Error fetching team members:", error);
    }
  };

  useEffect(() => {
    fetchTeamMembers();
  }, []);

  // Handle editing a team member
  const handleEditMember = (member) => {
    setCurrentMember(member);
    setNewMember({
      firstName: member.firstName,
      lastName: member.lastName,
      email: member.email,
      role: member.role,
      permissions: member.permissions,
    });
    setShowEditMember(true);
  };

  // Handle saving edited member
  const handleSaveMember = () => {
    const updatedMember = { ...newMember, id: currentMember.id };

    setTeamMembers((prevMembers) =>
      prevMembers.map((member) =>
        member.id === currentMember.id ? updatedMember : member
      )
    );
    setShowEditMember(false);
    setCurrentMember(null);

    // Optional: Send the updated member back to the server
    // const response = await fetch(`/api/team/${currentMember.id}`, {
    //   method: "PUT",
    //   headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify(updatedMember),
    // });
    // if (!response.ok) {
    //   console.error("Failed to save member changes");
    // }
  };

  // Handle adding a new team member
  const handleAddMember = () => {
    const newTeamMember = { ...newMember, id: Date.now() };

    setTeamMembers((prevMembers) => [...prevMembers, newTeamMember]);
    setShowAddMember(false);
    setNewMember({
      firstName: "",
      lastName: "",
      email: "",
      role: "",
      permissions: ["view", "edit", "delete"],
    });

    // Optional: Send the new member to the server
    // const response = await fetch("/api/team", {
    //   method: "POST",
    //   headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify(newTeamMember),
    // });
    // if (!response.ok) {
    //   console.error("Failed to add team member");
    // }
  };

  return (
    <div className="p-4">
      <h2 className="text-3xl font-bold text-accent mb-6">Teams</h2>

      {/* Add Team Member Button */}
      <button
        onClick={() => setShowAddMember(!showAddMember)}
        className="px-4 py-2 mb-6 bg-accent text-white rounded-md"
      >
        {showAddMember ? "Cancel Add Member" : "Add Team Member"}
      </button>

      {/* Add Team Member Form */}
      {showAddMember && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Add New Team Member</h3>
          {/* Form Fields */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">First Name</label>
            <input
              type="text"
              placeholder="Enter first name"
              value={newMember.firstName}
              onChange={(e) => setNewMember({ ...newMember, firstName: e.target.value })}
              className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
            />
          </div>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Last Name</label>
            <input
              type="text"
              placeholder="Enter last name"
              value={newMember.lastName}
              onChange={(e) => setNewMember({ ...newMember, lastName: e.target.value })}
              className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
            />
          </div>
          {/* Other Fields */}
          <button
            onClick={handleAddMember}
            className="px-4 py-2 bg-green-500 text-white rounded-md"
          >
            Add Member
          </button>
        </div>
      )}

      {/* Team Member List */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-2xl font-semibold text-gray-800 mb-4">Team Members</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full table-auto">
            <thead>
              <tr>
                <th className="py-2 px-4 text-left">Name</th>
                <th className="py-2 px-4 text-left">Email</th>
                <th className="py-2 px-4 text-left">Role</th>
                <th className="py-2 px-4 text-left">Permissions</th>
                <th className="py-2 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {teamMembers.map((member) => (
                <tr key={member.id} className="border-t">
                  <td className="py-2 px-4">{`${member.firstName} ${member.lastName}`}</td>
                  <td className="py-2 px-4">{member.email}</td>
                  <td className="py-2 px-4">{member.role}</td>
                  <td className="py-2 px-4">{permissionsList.join(", ")}</td>
                  <td className="py-2 px-4">
                    <button
                      onClick={() => handleEditMember(member)}
                      className="px-4 py-2 bg-blue-500 text-white rounded-md"
                    >
                      Edit
                    </button>
                    <button className="ml-2 px-4 py-2 bg-red-500 text-white rounded-md">
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Team Member Modal */}
      {showEditMember && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-2xl font-semibold mb-4">Edit Team Member</h3>
            {/* Modal Fields */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">First Name</label>
              <input
                type="text"
                value={newMember.firstName}
                onChange={(e) => setNewMember({ ...newMember, firstName: e.target.value })}
                className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
              />
            </div>
            {/* Other Fields */}
            <button
              onClick={handleSaveMember}
              className="px-4 py-2 bg-green-500 text-white rounded-md"
            >
              Save Changes
            </button>
            <button
              onClick={() => setShowEditMember(false)}
              className="ml-2 px-4 py-2 bg-gray-500 text-white rounded-md"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Teams;
