import React from "react";

const Dashboard = () => {
  const stats = [
    { title: "Total Revenue", value: "$12,340", color: "bg-green-100 text-green-800" },
    { title: "Active Reservations", value: "85", color: "bg-blue-100 text-blue-800" },
    { title: "Team Members", value: "15", color: "bg-purple-100 text-purple-800" },
    { title: "Pending Reviews", value: "5", color: "bg-yellow-100 text-yellow-800" },
  ];

  return (
    <div className="h-screen flex bg-background">

      {/* Main Content */}
      <main className="flex-1 m-4">
        <h2 className="text-3xl font-bold text-accent mb-6">Dashboard</h2>

        {/* Statistics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`p-6 rounded-lg shadow-lg ${stat.color}`}
            >
              <h3 className="text-lg font-semibold">{stat.title}</h3>
              <p className="text-2xl font-bold">{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Example Chart 1 */}
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Revenue Overview</h3>
            <div className="flex items-center justify-center h-48 bg-gray-100 rounded">
              {/* Placeholder for Chart */}
              <p className="text-gray-500">[Insert Revenue Chart]</p>
            </div>
          </div>

          {/* Example Chart 2 */}
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Reservations Trends</h3>
            <div className="flex items-center justify-center h-48 bg-gray-100 rounded">
              {/* Placeholder for Chart */}
              <p className="text-gray-500">[Insert Reservations Chart]</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
