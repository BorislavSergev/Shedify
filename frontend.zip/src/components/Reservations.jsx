import React, { useState } from "react";

const Reservations = () => {
  const [activeTab, setActiveTab] = useState("waiting");

  const dummyReservations = [
    {
      id: 1,
      service: "Haircut",
      time: "2024-12-12 10:00 AM",
      firstName: "John",
      lastName: "Doe",
      phone: "123-456-7890",
      email: "john.doe@example.com",
      duration: "30 minutes",
      total: "$25",
      status: "waiting",
    },
    {
      id: 2,
      service: "Manicure",
      time: "2024-12-12 11:30 AM",
      firstName: "Jane",
      lastName: "Smith",
      phone: "987-654-3210",
      email: "jane.smith@example.com",
      duration: "45 minutes",
      total: "$40",
      status: "accepted",
    },
    {
      id: 3,
      service: "Facial",
      time: "2024-12-12 01:00 PM",
      firstName: "Alice",
      lastName: "Brown",
      phone: "456-789-1234",
      email: "alice.brown@example.com",
      duration: "1 hour",
      total: "$60",
      status: "declined",
    },
  ];

  const filteredReservations = dummyReservations.filter(
    (reservation) => reservation.status === activeTab
  );

  return (
    <div className="p-4">
      <h2 className="text-3xl font-bold text-accent mb-6">Reservations</h2>

      {/* Tabs for Status */}
      <div className="flex gap-4 mb-6">
        {["waiting", "accepted", "declined"].map((status) => (
          <button
            key={status}
            onClick={() => setActiveTab(status)}
            className={`px-4 py-2 rounded-md ${
              activeTab === status
                ? "bg-accent text-white"
                : "bg-gray-200 text-gray-700"
            }`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      {/* Reservation List */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        {filteredReservations.length > 0 ? (
          <table className="min-w-full table-auto">
            <thead>
              <tr>
                <th className="py-2 px-4 text-left">Service</th>
                <th className="py-2 px-4 text-left">Time</th>
                <th className="py-2 px-4 text-left">Customer</th>
                <th className="py-2 px-4 text-left">Phone</th>
                <th className="py-2 px-4 text-left">Email</th>
                <th className="py-2 px-4 text-left">Duration</th>
                <th className="py-2 px-4 text-left">Total</th>
                <th className="py-2 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredReservations.map((reservation) => (
                <tr key={reservation.id} className="border-t">
                  <td className="py-2 px-4">{reservation.service}</td>
                  <td className="py-2 px-4">{reservation.time}</td>
                  <td className="py-2 px-4">
                    {reservation.firstName} {reservation.lastName}
                  </td>
                  <td className="py-2 px-4">{reservation.phone}</td>
                  <td className="py-2 px-4">{reservation.email}</td>
                  <td className="py-2 px-4">{reservation.duration}</td>
                  <td className="py-2 px-4">{reservation.total}</td>
                  <td className="py-2 px-4">
                    <button className="px-4 py-2 bg-blue-500 text-white rounded-md">
                      Edit
                    </button>
                    <button className="ml-2 px-4 py-2 bg-red-500 text-white rounded-md">
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No reservations found for this status.</p>
        )}
      </div>
    </div>
  );
};

export default Reservations;
