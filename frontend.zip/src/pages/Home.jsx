import React from "react";

const Home = () => {
  return (
    <div className="font-sans">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-20 text-center">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Welcome to Our Company
          </h1>
          <p className="text-lg md:text-xl mb-8">
            We deliver exceptional services tailored to your needs.
          </p>
          <button className="px-6 py-3 bg-white text-blue-600 font-bold rounded-lg hover:bg-gray-100 transition">
            Get Started
          </button>
        </div>
      </section>

      {/* About Us Section */}
      <section className="py-16 bg-gray-100 text-gray-700">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">About Us</h2>
          <p className="text-lg">
            Our company has been providing top-notch services for over a decade.
            Our mission is to exceed customer expectations through unparalleled quality
            and dedication.
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {["Quality Service", "Affordable Pricing", "Customer Support"].map(
              (feature, idx) => (
                <div
                  key={idx}
                  className="bg-gray-100 p-6 text-center rounded-lg shadow-lg"
                >
                  <h3 className="text-xl font-bold mb-4">{feature}</h3>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
                    consequat.
                  </p>
                </div>
              )
            )}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-gray-100">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-12">Pricing</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { plan: "Basic", price: "$10/month", features: ["Feature A", "Feature B"] },
              { plan: "Standard", price: "$20/month", features: ["Feature A", "Feature B", "Feature C"] },
              { plan: "Premium", price: "$30/month", features: ["Feature A", "Feature B", "Feature C", "Feature D"] },
            ].map((tier, idx) => (
              <div
                key={idx}
                className="bg-white p-6 rounded-lg shadow-lg border-t-4 border-blue-500"
              >
                <h3 className="text-xl font-bold mb-4">{tier.plan}</h3>
                <p className="text-2xl font-bold mb-6">{tier.price}</p>
                <ul className="mb-6">
                  {tier.features.map((feature, idx) => (
                    <li key={idx} className="text-gray-700">
                      ✅ {feature}
                    </li>
                  ))}
                </ul>
                <button className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition">
                  Choose Plan
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-12">Frequently Asked Questions</h2>
          <div className="space-y-8">
            {[
              {
                question: "What services do you offer?",
                answer: "We offer a variety of services tailored to meet your needs.",
              },
              {
                question: "How can I contact customer support?",
                answer: "You can contact us via email or phone, available 24/7.",
              },
              {
                question: "Do you have a refund policy?",
                answer: "Yes, we offer a 30-day money-back guarantee for all plans.",
              },
            ].map((faq, idx) => (
              <div key={idx}>
                <h3 className="text-lg font-bold mb-2">{faq.question}</h3>
                <p className="text-gray-700">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Us Section */}
      <section className="py-16 bg-gray-100">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
          <p className="text-lg mb-8">
            Have questions? Reach out to us using the form below.
          </p>
          <form className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="First Name"
                className="p-3 border border-gray-300 rounded-md w-full"
              />
              <input
                type="text"
                placeholder="Last Name"
                className="p-3 border border-gray-300 rounded-md w-full"
              />
            </div>
            <input
              type="email"
              placeholder="Email Address"
              className="p-3 border border-gray-300 rounded-md w-full"
            />
            <textarea
              rows="4"
              placeholder="Your Message"
              className="p-3 border border-gray-300 rounded-md w-full"
            ></textarea>
            <button
              type="submit"
              className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
            >
              Send Message
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Home;
