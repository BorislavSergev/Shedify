import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [rememberMe, setRememberMe] = useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleRememberMeChange = () => {
    setRememberMe(!rememberMe);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessages([]);
    
    if (!formData.email || !formData.password) {
      setErrorMessages(["Email and password are required."]);
      return;
    }
  
    try {
      setLoading(true);
  
      // Send login request
      const loginResponse = await axios.post(
        "http://localhost:3000/api/users/login",
        { ...formData, rememberMe },
        { withCredentials: true }
      );
  
      const { token } = loginResponse.data;
  
      // Store the token in localStorage
      localStorage.setItem("token", token);
  
      try {
        // Fetch the user's businesses
        const businessResponse = await axios.get(
          "http://localhost:3000/api/businesses/user-businesses",
          {
            withCredentials: true,
            headers: { Authorization: `Bearer ${token}` },
          }
        );
  
        // If businesses are found, navigate to the dashboard
        navigate("/dashboard");
      } catch (businessError) {
        // Handle 404 for no businesses
        if (businessError.response?.status === 404) {
          console.log("No businesses found. Redirecting to create-business.");
          navigate("/create-business"); // Redirect to create-business
        } else {
          throw businessError; // Rethrow other errors
        }
      }
    } catch (error) {
      // Handle login or other errors
      console.error(error);
      setErrorMessages([
        error.response?.data?.message || "Unable to log in. Please try again later.",
      ]);
    } finally {
      setLoading(false);
    }
  };
  

  return (
    <div className="flex h-screen justify-center items-center bg-primary">
      <div className="w-full max-w-md p-8 bg-white shadow-lg rounded-lg">
        <h2 className="text-2xl font-bold text-center mb-6">Sign In</h2>
        {errorMessages.length > 0 && (
          <div className="bg-red-100 text-red-700 p-3 rounded mb-4">
            {errorMessages.map((msg, idx) => (
              <p key={idx}>{msg}</p>
            ))}
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-sm font-medium mb-2" htmlFor="email">
              Email
            </label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email"
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div className="mb-6">
            <label className="block text-sm font-medium mb-2" htmlFor="password">
              Password
            </label>
            <input
              id="password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Enter your password"
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div className="mb-6 flex items-center">
            <input
              id="remember_me"
              type="checkbox"
              checked={rememberMe}
              onChange={handleRememberMeChange}
              className="mr-2"
            />
            <label htmlFor="remember_me" className="text-sm font-medium">
              Remember me
            </label>
          </div>
          <button
            type="submit"
            className={`w-full py-2 rounded-md text-white ${
              loading ? "bg-gray-400 cursor-not-allowed" : "bg-accent hover:bg-accentHover"
            }`}
            disabled={loading}
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
