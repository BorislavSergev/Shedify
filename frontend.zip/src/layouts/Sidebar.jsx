import React, { useState } from "react";
import { Link } from "react-router-dom";
import { FaClock, FaCogs, FaHistory, FaClipboardList, FaBars } from "react-icons/fa";


import { MdDashboard, MdSubscriptions } from "react-icons/md";
import { BsFillPeopleFill } from "react-icons/bs";



const Sidebar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Toggle mobile menu
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <>
      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-52 bg-white text-gray-700 shadow-2xl z-20 transform transition-transform duration-300 ${isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
          } md:translate-x-0 md:relative md:shadow-md`}
      >
        <h1 className="text-3xl font-bold text-accent mb-8 text-center mt-6">Shedify</h1>
        <div className="flex flex-col gap-6">
          <nav className="flex flex-col gap-4">
            <Link
              to="/dashboard"
              className="flex items-center text-lg py-2 px-4 rounded-md hover:bg-gray-100 hover:text-accent transition"
            >
              <MdDashboard className="w-6 h-6 mr-3" />
              <span>Dashboard</span>
            </Link>
            <Link
              to="/dashboard/team"
              className="flex items-center text-lg py-2 px-4 rounded-md hover:bg-gray-100 hover:text-accent transition"
            >
              <BsFillPeopleFill className="w-5 h-5 mr-3" />
              <span>Team</span>
            </Link>
            <Link
              to="/dashboard/settings"
              className="flex items-center text-lg py-2 px-4 rounded-md hover:bg-gray-100 hover:text-accent transition"
            >
              <FaCogs className="w-6 h-6 mr-3" />
              <span>Settings</span>
            </Link>
            <Link
              to="/dashboard/reservations"
              className="flex items-center text-lg py-2 px-4 rounded-md hover:bg-gray-100 hover:text-accent transition"
            >
              <FaClock className="w-5 h-5 mr-3" />
              <span>Reservations</span>
            </Link>
            <Link
              to="/dashboard/services"
              className="flex items-center text-lg py-2 px-4 rounded-md hover:bg-gray-100 hover:text-accent transition"
            >
              <FaClipboardList className="w-5 h-5 mr-3" />
              <span>Services</span>
            </Link>

            <Link
              to="/history"
              className="flex items-center text-lg py-2 px-4 rounded-md hover:bg-gray-100 hover:text-accent transition"
            >
              <MdSubscriptions className="w-5 h-5 mr-3" />
              <span>Subscription</span>
            </Link>
          </nav>
        </div>
      </aside>

      {/* Mobile Menu Toggle Button */}
      <div
        className="md:hidden fixed top-1 left-2 z-50 p-4 cursor-pointer"
        onClick={toggleMobileMenu}
      >
        <FaBars className="text-2xl text-gray-700" />
      </div>
    </>
  );
};

export default Sidebar;
