import React, { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaBars, FaPlus } from "react-icons/fa";
import axios from "axios";

const HeaderDashboard = ({ onSidebarToggle }) => {
  const [isBusinessDropdownOpen, setIsBusinessDropdownOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  const [selectedBusiness, setSelectedBusiness] = useState(() => {
    const savedBusiness = localStorage.getItem("selectedBusiness");
    return savedBusiness ? JSON.parse(savedBusiness) : { id: null, name: "Select a Business" };
  });

  const businessDropdownRef = useRef(null);
  const profileDropdownRef = useRef(null);

  const toggleBusinessDropdown = () => {
    setIsBusinessDropdownOpen(!isBusinessDropdownOpen);
  };

  const toggleProfileDropdown = () => {
    setIsProfileDropdownOpen(!isProfileDropdownOpen);
  };

  const closeDropdowns = () => {
    setIsBusinessDropdownOpen(false);
    setIsProfileDropdownOpen(false);
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    const fetchBusinesses = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await axios.get("http://localhost:3000/api/businesses/user-businesses", {
          withCredentials: true,
          headers: { Authorization: `Bearer ${token}` },
        });
        if (response.data.success) {
          const fetchedBusinesses = response.data.businesses;
          setBusinesses(fetchedBusinesses);

          if (fetchedBusinesses.length === 1) {
            const soleBusiness = { id: fetchedBusinesses[0].id, name: fetchedBusinesses[0].name };
            setSelectedBusiness(soleBusiness);
            localStorage.setItem("selectedBusiness", JSON.stringify(soleBusiness));
          }
        } else {
          setError(response.data.message || "An unknown error occurred.");
        }
      } catch (err) {
        setError(err.response?.data?.message || "Server error. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    fetchBusinesses();
  }, []);

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (
        businessDropdownRef.current &&
        !businessDropdownRef.current.contains(event.target) &&
        profileDropdownRef.current &&
        !profileDropdownRef.current.contains(event.target)
      ) {
        closeDropdowns();
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, []);

  const handleBusinessSelect = (business) => {
    const selected = { id: business.id, name: business.name };
    setSelectedBusiness(selected);
    setIsBusinessDropdownOpen(false);
    localStorage.setItem("selectedBusiness", JSON.stringify(selected));
  };

  return (
    <header className="bg-white sticky top-0 z-20 shadow-md w-full">
      <div className="flex items-center justify-between px-4 sm:px-6 lg:px-8 h-16">
        <button
          className="md:hidden p-2 text-gray-600 hover:text-gray-800"
          onClick={onSidebarToggle}
        >
          <FaBars className="text-2xl" />
        </button>

        <div
          className="relative flex-1 flex items-center justify-center md:justify-start"
          ref={businessDropdownRef}
        >
          <button
            className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-600"
            onClick={toggleBusinessDropdown}
          >
            <span className="truncate">{selectedBusiness.name}</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className={`w-4 h-4 transform transition-transform ${isBusinessDropdownOpen ? "rotate-180" : ""}`}
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M5.23 7.21a.75.75 0 011.06.02L10 10.707l3.71-3.475a.75.75 0 111.02 1.1l-4 3.75a.75.75 0 01-1.02 0l-4-3.75a.75.75 0 01.02-1.062z"
                clipRule="evenodd"
              />
            </svg>
          </button>
          {isBusinessDropdownOpen && (
            <div
              className="absolute top-full left-0 mt-2 w-64 bg-white shadow-lg rounded-md border divide-y divide-gray-100 z-30"
              style={{ minWidth: "12rem" }}
            >
              {loading ? (
                <div className="block px-4 py-2 text-sm text-gray-500">Loading...</div>
              ) : error ? (
                <div className="block px-4 py-2 text-sm text-red-500">{error}</div>
              ) : businesses.length > 0 ? (
                <ul>
                  {businesses.map((business) => (
                    <li
                      key={business.id}
                      className="block px-4 py-2 text-sm text-gray-500 hover:bg-gray-50 cursor-pointer"
                      onClick={() => handleBusinessSelect(business)}
                    >
                      {business.name}
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="block px-4 py-2 text-sm text-gray-500">No businesses available</div>
              )}
              <div
                className="flex items-center px-4 py-2 text-sm text-accent hover:bg-itemsHover cursor-pointer"
                onClick={() => navigate("/create-business")}
              >
                <FaPlus className="mr-2" />
                Create Business
              </div>
            </div>
          )}
        </div>

        <div className="relative" ref={profileDropdownRef}>
          <button
            className="overflow-hidden rounded-full border border-gray-300 shadow-inner"
            onClick={toggleProfileDropdown}
          >
            <span className="sr-only">Toggle profile menu</span>
            <div className="bg-accent text-white w-8 h-8 flex items-center justify-center rounded-full">
              B
            </div>
          </button>
          {isProfileDropdownOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white shadow-lg rounded-md border divide-y divide-gray-100 z-30">
              <div className="p-2">
                <Link
                  to="/profile"
                  className="block px-4 py-2 text-sm text-gray-500 hover:bg-gray-50"
                  onClick={closeDropdowns}
                >
                  My Profile
                </Link>
              </div>
              <div className="p-2">
                <button
                  className="block w-full text-left px-4 py-2 text-sm text-red-700 hover:bg-red-50"
                  onClick={() => console.log("Sign Out")}
                >
                  Sign Out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default HeaderDashboard;
