import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import axios from "axios";
import BusinessLayout from "./layouts/BusinessLayout"; //done
import DefaultLayout from "./layouts/DefaultLayout"; //done
import Dashboard from "./components/Dashboard"; //done
import Settings from "./components/Settings";
import Login from "./pages/Login"; //done
import Register from "./pages/Register"; //done
import Teams from "./components/Teams";
import CreateBusiness from "./pages/CreateBusiness "; //done
import Reservations from "./components/Reservations";
import Services from "./components/Services";
import Home from "./pages/Home";

const App = () => {
  const [user, setUser] = useState(null); // Track user state (null means not logged in)
  const [loading, setLoading] = useState(true); // Loading state while validating token

  // Validate token when the app loads
  useEffect(() => {
    const validateToken = async () => {
      const token = localStorage.getItem("token"); // Retrieve token from localStorage

      try {
        const response = await axios.get("http://localhost:3000/api/users/validate-token", {

          withCredentials: true,
          headers: { Authorization: `Bearer ${token}` },
          // Ensure cookies are included with the request
        });

        // If token is valid, set user state
        setUser(response.data);
      } catch (error) {
        console.log("Token validation failed:", error.response?.data?.message);
        setUser(null); // If token is invalid or expired, set user to null
      } finally {
        setLoading(false); // Stop loading once token validation is complete
      }
    };

    validateToken();
  }, []);

  // Handle loading state: show a loading indicator or prevent rendering until token validation is done
  if (loading) {
    return <div>Loading...</div>; // You can replace this with a spinner or something more user-friendly
  }

  return (
    <Router>
      <Routes>
        {/* BusinessLayout Routes (with Sidebar) */}
        <Route element={<BusinessLayout />}>
          {/* Protected route, only accessible if user is logged in */}
          <Route path="/dashboard" element={user ? <Dashboard /> : <Navigate to="/login" />} />
          <Route path="/dashboard/settings" element={user ? <Settings /> : <Navigate to="/login" />} />
          <Route path="/dashboard/team" element={user ? <Teams /> : <Navigate to="/login" />} />
          <Route path="/dashboard/services" element={user ? <Services /> : <Navigate to="/login" />} />
          <Route path="/dashboard/reservations" element={user ? <Reservations /> : <Navigate to="/login" />} />          
        </Route>

        {/* DefaultLayout Routes (no Sidebar) */}
        <Route element={<DefaultLayout />}>
          <Route path="*" element={<Home/>} />

          {/* Login and Register Routes, redirect if user is already logged in */}
          <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <Login />} />
          <Route path="/register" element={user ? <Navigate to="/dashboard" /> : <Register />} />
          <Route path="/create-business" element={<> <CreateBusiness /></>} />

        </Route>
      </Routes>
    </Router>
  );
};

export default App;
